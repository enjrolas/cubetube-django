/**
 ******************************************************************************
 * @file    deviceid_hal.cpp
 * @author  Matthew McGowan
 * @version V1.0.0
 * @date    25-Sept-2014
 * @brief
 ******************************************************************************
  Copyright (c) 2013-14 Spark Labs, Inc.  All rights reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************
 */


#include "deviceid_hal.h"
#include "platform_config.h"
#include <algorithm>
#include <cstring>

const unsigned device_id_len = 12;

unsigned HAL_device_ID(uint8_t* dest, unsigned destLen)
{    
    if (dest!=NULL && destLen!=0)
        memcpy(dest, (char*)ID1, std::min(destLen, device_id_len));
    return device_id_len;
}

unsigned HAL_Platform_ID()
{
    return PLATFORM_ID;
}