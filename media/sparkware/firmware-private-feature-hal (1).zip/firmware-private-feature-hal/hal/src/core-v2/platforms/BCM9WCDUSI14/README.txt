Provider    : Broadcom / USI
Website     : http://www.broadcom.com/support/wiced
Description : WICED Wi-Fi module manufactured by USI 

Schematic & Photo : /platforms/BCM9WCDUSI14/schematics/

Wi-Fi Module 
  Mfr     : USI
  P/N     : WM-N-BM-14
  MCU     : STM32F205RGY6
  WLAN    : BCM43362
  Antenna : Diversity with printed antenna and external u.FL connector
