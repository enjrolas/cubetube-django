/*
 * Copyright 2014, Broadcom Corporation
 * All Rights Reserved.
 *
 * This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
 * the contents of this file may not be disclosed to third parties, copied
 * or duplicated in any form, in whole or in part, without the prior
 * written permission of Broadcom Corporation.
 */

#ifndef INCLUDED_PERF_H
#define INCLUDED_PERF_H

#ifdef __cplusplus
extern "C" {
#endif

#define PERF_START
#define PERF_STOP(x)

#ifdef __cplusplus
} /*extern "C" */
#endif

#endif /* ifndef INCLUDED_PERF_H */
