/* 
 * File:   ledcontrol.h
 * Author: mat
 *
 * Created on 14 March 2015, 22:14
 */

#ifndef LEDCONTROL_H
#define	LEDCONTROL_H

#include <stdint.h>

#ifdef	__cplusplus
extern "C" {
#endif

    
extern volatile uint8_t SPARK_LED_FADE;


#ifdef	__cplusplus
}
#endif

#endif	/* LEDCONTROL_H */

