
#define DYNALIB_IMPORT
#include "communication_dynalib.h"

