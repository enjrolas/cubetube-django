#include "hal_dynalib_i2c.h"
