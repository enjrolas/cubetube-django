#include "UnitTest++.h"

int main(int, char const *[])
{
  return UnitTest::RunAllTests();
}
