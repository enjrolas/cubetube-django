
#define CATCH_CONFIG_MAIN 
#include "catch.hpp"

// Because of the #define above we cannot use the precompiled header here
// So try not to modify this file.