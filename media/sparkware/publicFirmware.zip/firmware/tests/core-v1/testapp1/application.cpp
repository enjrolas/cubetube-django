
#include "application.h"
#include "unit-test/unit-test.h"

UNIT_TEST_APP();