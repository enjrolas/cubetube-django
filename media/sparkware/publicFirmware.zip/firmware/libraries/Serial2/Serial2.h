#ifndef __LIB_SERIAL2_H
#define __LIB_SERIAL2_H

#include "spark_wiring_usartserial.h"

// instantiate Serial2
USARTSerial Serial2(&USART_MAP[USART_D1_D0]);

#endif


