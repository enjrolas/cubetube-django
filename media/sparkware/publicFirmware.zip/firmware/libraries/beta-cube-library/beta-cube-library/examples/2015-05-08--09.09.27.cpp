Cube cube;
void setup()
{
    size(500,500, P3D); 
    cube=new Cube(this);
    smooth();
}

void draw()
{
	cube.background(color(50,50,50));
    cube.draw();
}
