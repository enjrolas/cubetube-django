#ifndef __INC_FASTLED_ARM_K26_H
#define __INC_FASTLED_ARM_K26_H

// Include the k20 headers
#include "delay.h"
#include "fastpin_arm_k26.h"
#include "fastspi_arm_k26.h"
#include "clockless_arm_k26.h"

#endif
