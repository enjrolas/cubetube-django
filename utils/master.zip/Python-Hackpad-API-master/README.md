Python-Hackpad-API
==================

A simple wrapper library for the Hackpad API. [Hackpad API Documentation](https://hackpad.com/Public-Hackpad-API-Draft-nGhsrCJFlP7)


Usage
==================

```python
temp = Hackpad('your_hackpad_subdomain','your_hackpad_client_id','your_hackpad_secret')
my_hackpads = temp.list_all()
````
